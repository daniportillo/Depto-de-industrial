function setUpdateAction() {
document.formnoticias.action = "editar.php";
document.formnoticias.submit();
}
