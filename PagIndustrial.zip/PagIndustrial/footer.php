 <footer class="footer row">
        <table>
          <tr>
            <td class="imgfooter"><img class="logocsti" src="img/logocsti.png"></td>
            <td class="textfooter">Centro de Servicios de Tecnologías de la Información  |  Edificio 5G-204 <br>
               Departamento de Ingeniería Industrial  |  <u><a class="linkuson" target="_blank" href="http://www.uson.mx/">Universidad de Sonora</a></u> 2015</td>
            <td class="imgfooter"><a target="_blank" href="https://www.facebook.com/pages/Departamento-de-Ingenieria-Industrial-Universidad-de-Sonora/174812735976678"><img align="right" class="faceicon" src="img/faceicon.png"></a></td>
          </tr> 
        </table>          
  </footer>