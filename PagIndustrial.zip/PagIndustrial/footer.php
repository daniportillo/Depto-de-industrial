<footer class="text-center footer">
        <div class="row text-center">
            <div class="col-md-6 col-md-offset-3">
                <br>
                <!--<img class="logocsti" src="img/logocsti.png"> -->
                Centro de Servicios de Tecnologias de la Información
                <p>Edificio 5G-204, Universidad de Sonora</p>
            </div>  
        </div>
    </footer>
